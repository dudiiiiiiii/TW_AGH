package pl.edu.agh.macwozni.dmeshparallel.production;

public interface PDrawer<P> {

    public void draw(P p);

}
